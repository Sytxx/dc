<?php
# config by : muh maulana
# channel : xatoshi lanzz
# telegram : @xatoshilanzz & @cxatoshi

$email = "xxxxxx";
$password = "xxxxxx";
?>
